import os

# Simulated response generator (mock LangChain logic)
class SimpleChatBot:
    def __init__(self):
        self.memory = []

    def run(self, user_input):
        self.memory.append(("User", user_input))
        # Placeholder logic: echoing user input with a simple response
        response = f"You said: {user_input}. This is a placeholder response."
        self.memory.append(("Bot", response))
        return response

def simulate_conversation(inputs):
    bot = SimpleChatBot()
    outputs = []
    for message in inputs:
        response = bot.run(message)
        outputs.append((message, response))
    return outputs

# Sample test cases (non-interactive for sandbox compatibility)
if __name__ == '__main__':
    test_inputs = [
        "Hello",
        "What's the weather today?",
        "Tell me a joke",
        "exit"
    ]
    results = simulate_conversation(test_inputs)
    for user_input, bot_response in results:
        print(f"You: {user_input}\nBot: {bot_response}\n")
